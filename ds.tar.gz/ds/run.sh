#!/bin/bash

java -jar Dummy_Slave.jar
